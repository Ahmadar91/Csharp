﻿using System;

namespace assignment2
{
	class MainProgram
	{
		static void Main(string[] args)
		{
			Menu menu = new Menu();
			menu.Start();
		}
	}
}